const h1 = document.querySelector("h1");
const p = document.querySelector("p");

const btnWrap1 = document.querySelector(".btnWrap1");
const btnWrap2 = document.querySelector(".btnWrap2");

const zero = document.querySelector(".zero");
zero.addEventListener("click", () => {
  h1.innerText = h1.innerText + zero.innerText;
  getResult(h1.innerText)
});

const point = document.querySelector(".point");
point.addEventListener("click", () => {
  if (h1.innerText.length && !h1.innerText.includes(point.innerText))
    h1.innerText = h1.innerText + point.innerText;
});

const numList = [7, 8, 9, 4, 5, 6, 1, 2, 3];

const numBtnList = numList.map((el) => {
  const button = document.createElement("button");
  btnWrap1.append(button);
  button.className = "numBtn";
  button.innerText = el;
  return button;
});

function getResult(text) {
  for(let i = 0; i < text.length; i++) {
    if(text[i] === "*") {
      const arr = text.split(`${text[i]}`);
      p.innerText = arr[0] * arr[1];
    } else if(text[i] === "/") {
      const arr = text.split(`${text[i]}`);
      p.innerText = arr[0] / arr[1];
    } else if(text[i] === "+") {
      const arr = text.split(`${text[i]}`);
      p.innerText = +arr[0] + +arr[1];
    } else if(text[i] === "-") {
      const arr = text.split(`${text[i]}`);
      p.innerText = arr[0] - arr[1];
    } else if(text[i] === "%") {
      const arr = text.split(`${text[i]}`);
      p.innerText = arr[0] * arr[1] / 100
    }
  }
}

numBtnList.forEach((el) => {
  el.addEventListener("click", () => {
    h1.innerText = h1.innerText + el.innerText;
    getResult(h1.innerText);
  });
});

const actionList = ["/", "*", "-", "+"];

const actionBtnList = actionList.map((el) => {
  const button = document.createElement("button");
  btnWrap2.append(button);
  button.className = "actionBtn";
  button.innerText = el;
  return button;
});

actionBtnList.forEach((el) => {
  el.addEventListener("click", () => {
    el.innerText === "-" && !h1.innerText.length ? h1.innerText += el.innerText
    : h1.innerText.length && !actionList.includes(h1.innerText[h1.innerText.length - 1]) ? h1.innerText += el.innerText
    : null;
  });
});

const percent = document.getElementById("percent");
percent.addEventListener("click", () => {
  if (+h1.innerText) {
    h1.innerText = h1.innerText + percent.innerText;
  }
});

const ac = document.getElementById("ac");
ac.addEventListener("click", () => {
  h1.innerText = "";
  p.innerText = "";
});

const c = document.getElementById("c");
c.addEventListener("click", () => {
  const arr = h1.innerText.split("");
  arr.pop();
  h1.innerText = arr.join("");
});

const equal = document.querySelector(".iqual");

equal.addEventListener("click", () => {
  h1.innerText = p.innerText;
  p.innerText = "";
})